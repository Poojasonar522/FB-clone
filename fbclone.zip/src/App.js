import CenterBar from "./Components/CenterBar";
import Header from "./Components/Header";
import Main from "./Components/Main";
import RightBar from "./Components/RightBar";

function App() {
  return (
    <div className="App">
      <Header />
      <CenterBar />
      <RightBar />
      <Main />
    </div>
  );
}

export default App;
